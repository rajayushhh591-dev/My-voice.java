import os
import uuid
import subprocess
from pathlib import Path

import torch
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from openvoice import se_extractor
from openvoice.api import ToneColorConverter
from melo.api import TTS

BASE = Path(__file__).resolve().parent
CKPT = BASE / "checkpoints_v2"
REF = BASE / "reference_voice.wav"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

DEVICE = "cuda:0" if torch.cuda.is_available() else "cpu"

# OpenVoice V2 converter
converter = ToneColorConverter(
    str(CKPT / "converter" / "config.json"),
    device=DEVICE
)
converter.load_ckpt(str(CKPT / "converter" / "checkpoint.pth"))

if not REF.exists():
    raise RuntimeError("Put your voice file at backend/reference_voice.wav")

# Extract your voice's tone color once at startup.
TARGET_SE, _ = se_extractor.get_se(
    str(REF), converter, vad=False
)

app = FastAPI(title="My Voice Generator")

class GenerateRequest(BaseModel):
    text: str
    language: str = "EN"
    speed: float = 1.0

@app.get("/health")
def health():
    return {"ok": True, "device": DEVICE}

@app.post("/generate")
def generate(req: GenerateRequest):
    text = req.text.strip()
    if not text:
        raise HTTPException(400, "Text is empty")
    if len(text) > 5000:
        raise HTTPException(400, "Text is too long")

    lang = req.language.upper()
    allowed = {"EN", "ES", "FR", "ZH", "JP", "KR"}
    if lang not in allowed:
        raise HTTPException(
            400,
            f"OpenVoice V2 native demo languages are currently {sorted(allowed)}. "
            "Hindi/Hinglish needs a Hindi-capable base TTS model."
        )

    job = uuid.uuid4().hex
    tmp = OUT / f"{job}_base.wav"
    wav = OUT / f"{job}.wav"
    mp3 = OUT / f"{job}.mp3"

    model = TTS(language=lang, device=DEVICE)
    speaker_ids = model.hps.data.spk2id
    speaker_key = next(iter(speaker_ids))
    speaker_id = speaker_ids[speaker_key]

    source_se_path = CKPT / "base_speakers" / "ses" / f"{speaker_key.lower().replace('_','-')}.pth"
    if not source_se_path.exists():
        raise HTTPException(500, f"Missing speaker embedding: {source_se_path}")

    source_se = torch.load(str(source_se_path), map_location=DEVICE)

    model.tts_to_file(
        text, speaker_id, str(tmp), speed=max(0.5, min(2.0, req.speed))
    )

    converter.convert(
        audio_src_path=str(tmp),
        src_se=source_se,
        tgt_se=TARGET_SE,
        output_path=str(wav),
        message="@MyVoiceGenerator"
    )

    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(wav), "-codec:a", "libmp3lame", "-q:a", "2", str(mp3)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except Exception:
        mp3 = None

    tmp.unlink(missing_ok=True)

    return {
        "wav": f"/download/{wav.name}",
        "mp3": f"/download/{mp3.name}" if mp3 and mp3.exists() else None
    }

@app.get("/download/{filename}")
def download(filename: str):
    path = OUT / Path(filename).name
    if not path.exists():
        raise HTTPException(404, "File not found")
    media = "audio/wav" if path.suffix.lower() == ".wav" else "audio/mpeg"
    return FileResponse(path, media_type=media, filename=path.name)
