# My Voice Generator

Android app + local Python backend for text -> cloned voice -> WAV/MP3.

## Important
The Android app talks to the backend over HTTP. The backend is where OpenVoice V2 is loaded.
OpenVoice V2's official usage currently uses a Python/PyTorch environment and MeloTTS, so the first version is designed this way rather than pretending that full cloning runs natively on every Android phone.

## Backend setup
1. Install Python 3.9 and the OpenVoice V2 dependencies from the official OpenVoice repository.
2. Put your reference recording at `backend/reference_voice.wav`.
3. Download the OpenVoice V2 checkpoints into `backend/checkpoints_v2/`.
4. Install FastAPI, Uvicorn and pydub.
5. Run:
   `python backend/server.py`
6. On the Android phone, set the server URL to the computer's LAN address, e.g. `http://192.168.1.10:8000`.

The backend returns WAV. MP3 conversion is included when ffmpeg is available.

This project is intentionally simple: text input, generate, play, download WAV/MP3.
