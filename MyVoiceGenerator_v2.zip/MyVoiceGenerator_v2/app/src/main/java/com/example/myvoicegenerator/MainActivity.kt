package com.example.myvoicegenerator

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val server = findViewById<EditText>(R.id.server)
        val text = findViewById<EditText>(R.id.text)
        val status = findViewById<TextView>(R.id.status)
        val generate = findViewById<Button>(R.id.generate)
        val wav = findViewById<Button>(R.id.wav)
        val mp3 = findViewById<Button>(R.id.mp3)

        var wavUrl: String? = null
        var mp3Url: String? = null

        generate.setOnClickListener {
            val input = text.text.toString().trim()
            if (input.isEmpty()) {
                status.text = "पहले text लिखें"
                return@setOnClickListener
            }
            status.text = "Generating..."
            generate.isEnabled = false

            thread {
                try {
                    val body = JSONObject()
                    body.put("text", input)
                    body.put("language", "EN")
                    body.put("speed", 1.0)

                    val conn = URL("${server.text.toString().trimEnd('/')}/generate")
                        .openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.doOutput = true
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }

                    val response = conn.inputStream.bufferedReader().readText()
                    val json = JSONObject(response)
                    wavUrl = server.text.toString().trimEnd('/') + json.getString("wav")
                    if (!json.isNull("mp3")) {
                        mp3Url = server.text.toString().trimEnd('/') + json.getString("mp3")
                    }

                    runOnUiThread {
                        status.text = "Done"
                        wav.isEnabled = true
                        mp3.isEnabled = mp3Url != null
                        generate.isEnabled = true
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        status.text = "Error: ${e.message}"
                        generate.isEnabled = true
                    }
                }
            }
        }

        wav.setOnClickListener { wavUrl?.let { open(it) } }
        mp3.setOnClickListener { mp3Url?.let { open(it) } }
    }

    private fun open(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
